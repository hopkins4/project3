This project was created with a team of three students in the fall 2017 Compilers course.

This project consists of a web page that acts as a small address book, displaying and editing data about people. The page will be driven by javascript 
functions operating on the parts of the page. it uses html and css to layout the page and we attempted to use as little style information in the 
html as possible, use mainly css.

The page displays a list of names on the left side of the page, and when a name is selected, display the details for that contact on the
 right side of the page. The details should include at least a phone number field and an email address field.

When the page loads, it loads the contact information out of a javascript array (which is hard-coded in the document).

Allows the user to modify the information in an edit mode. Since the browser engine should not have access to the hard drive, 
one does not have to store the edited information across sessions.